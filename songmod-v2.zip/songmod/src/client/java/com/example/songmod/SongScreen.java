package com.example.songmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;

import java.util.Map;

public class SongScreen extends Screen {
    private static SoundInstance current;
    private final boolean showList;

    public SongScreen(boolean showList) {
        super(Component.literal("Songs"));
        this.showList = showList;
    }

    @Override
    protected void init() {
        int cx = width / 2 - 75;
        if (!showList) {
            addRenderableWidget(Button.builder(Component.literal("Song"),
                    b -> Minecraft.getInstance().setScreen(new SongScreen(true)))
                    .bounds(cx, height / 2 - 10, 150, 20).build());
        } else {
            int count = SongMod.SONGS.size();
            int step = Math.min(24, Math.max(15, (height - 80) / Math.max(1, count)));
            int y = 20;
            for (Map.Entry<String, SoundEvent> e : SongMod.SONGS.entrySet()) {
                addRenderableWidget(Button.builder(Component.literal(e.getKey()), b -> play(e.getValue()))
                        .bounds(cx, y, 150, Math.min(20, step - 2)).build());
                y += step;
            }
            addRenderableWidget(Button.builder(Component.literal("Stop"), b -> stop())
                    .bounds(cx, y + 8, 72, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Back"),
                    b -> Minecraft.getInstance().setScreen(new SongScreen(false)))
                    .bounds(cx + 78, y + 8, 72, 20).build());
        }
    }

    private static void play(SoundEvent sound) {
        stop();
        current = SimpleSoundInstance.forUI(sound, 1.0f);
        Minecraft.getInstance().getSoundManager().play(current);
    }

    private static void stop() {
        if (current != null) {
            Minecraft.getInstance().getSoundManager().stop(current);
            current = null;
        }
    }
}
