package com.example.songmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

public class SongMod implements ModInitializer {
    public static final String ID = "songmod";
    // Display name -> sound event (built-in songs first, then SongFold songs)
    public static final Map<String, SoundEvent> SONGS = new LinkedHashMap<>();

    private static SoundEvent reg(String name) {
        Identifier id = Identifier.fromNamespaceAndPath(ID, name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    @Override
    public void onInitialize() {
        // Built-in songs (bundled inside the mod)
        SONGS.put("Song 1", reg("song1"));
        SONGS.put("Song 2", reg("song2"));
        SONGS.put("Song 3", reg("song3"));

        try {
            loadSongFold();
        } catch (Exception e) {
            System.err.println("[SongMod] Could not load SongFold: " + e);
        }
    }

    /** Reads .minecraft/SongFold/*.ogg and exposes them through a generated resource pack. */
    private void loadSongFold() throws IOException {
        Path game = FabricLoader.getInstance().getGameDir();
        Path songFold = game.resolve("SongFold");
        Files.createDirectories(songFold);

        Path pack = game.resolve("resourcepacks").resolve("SongFoldPack");
        Path soundsDir = pack.resolve("assets").resolve(ID).resolve("sounds");
        Files.createDirectories(soundsDir);

        // clean old copies so deleted songs disappear
        try (Stream<Path> old = Files.list(soundsDir)) {
            for (Path p : (Iterable<Path>) old::iterator) Files.deleteIfExists(p);
        }

        StringBuilder json = new StringBuilder("{\n");
        boolean first = true;
        List<Path> files = new ArrayList<>();
        try (Stream<Path> s = Files.list(songFold)) {
            s.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".ogg")).sorted().forEach(files::add);
        }
        Set<String> used = new HashSet<>();
        for (Path f : files) {
            String fileName = f.getFileName().toString();
            String display = fileName.substring(0, fileName.length() - 4);
            String key = "custom_" + display.toLowerCase().replaceAll("[^a-z0-9_]", "_");
            while (!used.add(key)) key += "_";
            Files.copy(f, soundsDir.resolve(key + ".ogg"), StandardCopyOption.REPLACE_EXISTING);
            if (!first) json.append(",\n");
            first = false;
            json.append("  \"").append(key).append("\": { \"sounds\": [ { \"name\": \"")
                .append(ID).append(":").append(key).append("\", \"stream\": true } ] }");
            SONGS.put(display, reg(key));
        }
        json.append("\n}\n");

        Files.writeString(pack.resolve("assets").resolve(ID).resolve("sounds.json"), json.toString());
        Files.writeString(pack.resolve("pack.mcmeta"),
            "{ \"pack\": { \"description\": \"SongFold custom songs\", \"pack_format\": 75, "
          + "\"supported_formats\": { \"min_inclusive\": 34, \"max_inclusive\": 99 } } }");
    }
}
