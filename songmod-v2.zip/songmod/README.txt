SONG MOD
- RightShift (or "Songs" button in pause menu on mobile) -> Song -> pick a song.
- Built-in songs: song1/2/3.ogg (inside the mod).
- Custom songs: drop .ogg files into  .minecraft/SongFold/  then restart the game.
  Display name = file name. 
- ONE-TIME: Options > Resource Packs > enable "SongFoldPack" (created automatically on first launch).
  Then restart (or F3+T). Songs only play when that pack is enabled.
- Files must be Ogg Vorbis. Convert with: ffmpeg -i in.mp3 -c:a libvorbis out.ogg
