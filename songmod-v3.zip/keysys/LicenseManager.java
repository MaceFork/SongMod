package com.example.songmod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screens.Screen;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Set;

public class LicenseManager {
    // SHA-256 hashes of the valid keys (keys themselves are not stored in the mod)
    private static final Set<String> VALID = Set.of("0f594235327457c95c97ce831afa84ee8aa8594a67971292ef38eecbf92b278d", "ddd72213dfccdb8920fd9f0148800b850de54ceb42db675c1fbb94faa553915f", "0e5648424a2f48069c08bd427bf99bec621338d9dc5b635c52d9e54e4a2a8215");

    private static final Path FILE = FabricLoader.getInstance().getGameDir().resolve("songmod_key.txt");
    private static boolean unlocked = false;

    static {
        try {
            if (Files.exists(FILE)) unlocked = check(Files.readString(FILE));
        } catch (Exception ignored) {}
    }

    public static boolean isUnlocked() { return unlocked; }

    /** Returns true and remembers the key if it is valid. */
    public static boolean tryKey(String key) {
        if (check(key)) {
            unlocked = true;
            try { Files.writeString(FILE, key.trim()); } catch (Exception ignored) {}
            return true;
        }
        return false;
    }

    /** Which screen to open when the player presses RightShift / Songs. */
    public static Screen menu() {
        return unlocked ? new SongScreen(false) : new KeyScreen();
    }

    private static boolean check(String key) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256")
                    .digest(key.trim().getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return VALID.contains(sb.toString());
        } catch (Exception e) {
            return false;
        }
    }
}
