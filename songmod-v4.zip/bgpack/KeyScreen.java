package com.example.songmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class KeyScreen extends Screen {
    private EditBox box;
    private Button status;

    public KeyScreen() {
        super(Component.literal("Enter Key"));
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        GalaxyBg.draw(g, width, height);
    }

    @Override
    protected void init() {
        int cx = width / 2 - 100;
        int y = height / 2 - 50;

        Button title = Button.builder(Component.literal("Enter your key"), b -> {})
                .bounds(cx, y, 200, 20).build();
        title.active = false;
        addRenderableWidget(title);

        box = new EditBox(Minecraft.getInstance().font, cx, y + 30, 200, 20, Component.literal("Key"));
        box.setMaxLength(64);
        box.setHint(Component.literal("Paste key here"));
        addRenderableWidget(box);
        setInitialFocus(box);

        addRenderableWidget(Button.builder(Component.literal("Unlock"), b -> submit())
                .bounds(cx, y + 60, 200, 20).build());

        status = Button.builder(Component.literal(""), b -> {})
                .bounds(cx, y + 86, 200, 20).build();
        status.active = false;
        addRenderableWidget(status);
    }

    private void submit() {
        if (LicenseManager.tryKey(box.getValue())) {
            Minecraft.getInstance().setScreen(new SongScreen(false));
        } else {
            status.setMessage(Component.literal("Wrong key"));
        }
    }
}
