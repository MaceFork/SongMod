package com.example.songmod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

public class GalaxyBg {
    private static final Identifier TEX =
            Identifier.fromNamespaceAndPath(SongMod.ID, "textures/gui/bg.png");

    public static void draw(GuiGraphics g, int width, int height) {
        // stretch the 854x480 picture over the whole screen
        g.blit(RenderPipelines.GUI_TEXTURED, TEX, 0, 0, 0.0f, 0.0f, width, height, 854, 480, 854, 480);
        // light dark layer so the buttons are easy to read
        g.fill(0, 0, width, height, 0x55000000);
    }
}
