package com.example.songmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;

import java.util.Map;

public class SongScreen extends Screen {
    private static SoundInstance current;
    private final boolean showList; // false = only "Song" button, true = song list

    public SongScreen(boolean showList) {
        super(Text.literal("Songs"));
        this.showList = showList;
    }

    @Override
    protected void init() {
        int cx = width / 2 - 75;
        if (!showList) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Song"),
                    b -> client.setScreen(new SongScreen(true)))
                    .dimensions(cx, height / 2 - 10, 150, 20).build());
        } else {
            int count = SongMod.SONGS.size();
            int step = Math.min(24, Math.max(15, (height - 80) / Math.max(1, count)));
            int y = 20;
            for (Map.Entry<String, SoundEvent> e : SongMod.SONGS.entrySet()) {
                addDrawableChild(ButtonWidget.builder(Text.literal(e.getKey()), b -> play(e.getValue()))
                        .dimensions(cx, y, 150, Math.min(20, step - 2)).build());
                y += step;
            }
            addDrawableChild(ButtonWidget.builder(Text.literal("Stop"), b -> stop())
                    .dimensions(cx, y + 8, 72, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Back"),
                    b -> client.setScreen(new SongScreen(false)))
                    .dimensions(cx + 78, y + 8, 72, 20).build());
        }
    }

    private static void play(SoundEvent sound) {
        stop();
        current = PositionedSoundInstance.master(sound, 1.0f);
        MinecraftClient.getInstance().getSoundManager().play(current);
    }

    private static void stop() {
        if (current != null) {
            MinecraftClient.getInstance().getSoundManager().stop(current);
            current = null;
        }
    }
}
